// <-- constantes matter --> //
const Engine = Matter.Engine;
const World= Matter.World;
const Bodies = Matter.Bodies;
const Constraint = Matter.Constraint;
// <--               //               --> //
// <-- variaveis matter --> //
var engine, world;
// <--               //               --> //

// <-- variaveis das imagens --> //
    var runAnimation, slideAnimation,dieAnimation;
     var  defaultAnimation, jumpingAnimation, coinImage;
     var canvas;
// <--               //               --> //

// <-- variaveis dos personagens e objetos --> //
    var Rob;
    var platform;

// <--               //               --> //

// <-- preload --> //
function preload(){


}
// <--               //               --> //

// <-- setup --> //
function setup(){
    canvas = createCanvas(windowWidth,windowHeight);

    engine = Engine.create();
    world = engine.world;

    Rob = new ROB(width/10,height/3,width/10,height/10);
    platform = new Platform(width/10,height/2,width/10,height/7)

}
// <--               //               --> //

// <-- draw --> //
function draw(){

    background("#1e1e1e");
    Engine.update(engine);


    Rob.display();
    platform.display();

}
// <--               //               --> //